/* HAL dispatch engine — ported from hal-demo2, recolored to the City Post Sprint palette (near-black canvas, electric-lime accent, JetBrains Mono data). Top-level fns stay global so innerHTML onclick handlers resolve; init is deferred to window.HALBoot(), called by HAL.dc.html once Leaflet + DOM are ready. */

// ── Constants ────────────────────────────────────────────────────────────────
var Z9_LAT = 53.3459, Z9_LNG = -6.2594, Z9_KM = 4.5;
var SPD_CITY = 18, SPD_OUT = 25;

// ── Locations ─────────────────────────────────────────────────────────────────
var LOCS = {
  artane          : { n:'Artane', lat:53.380, lng:-6.200 },
  ashtown         : { n:'Ashtown', lat:53.372, lng:-6.308 },
  balbriggan      : { n:'Balbriggan', lat:53.611, lng:-6.182 },
  baldoyle        : { n:'Baldoyle', lat:53.395, lng:-6.134 },
  balgriffin      : { n:'Balgriffin', lat:53.412, lng:-6.158 },
  ballsbridge     : { n:'Ballsbridge', lat:53.318, lng:-6.228 },
  ballyboden      : { n:'Ballyboden', lat:53.274, lng:-6.288 },
  ballybough      : { n:'Ballybough', lat:53.361, lng:-6.239 },
  ballybrack      : { n:'Ballybrack', lat:53.249, lng:-6.138 },
  ballyfermot     : { n:'Ballyfermot', lat:53.341, lng:-6.368 },
  ballymun        : { n:'Ballymun', lat:53.404, lng:-6.257 },
  bayside         : { n:'Bayside', lat:53.387, lng:-6.148 },
  beaumont        : { n:'Beaumont', lat:53.387, lng:-6.227 },
  blackrock       : { n:'Blackrock', lat:53.302, lng:-6.178 },
  blanchardstown  : { n:'Blanchardstown', lat:53.389, lng:-6.378 },
  booterstown     : { n:'Booterstown', lat:53.306, lng:-6.201 },
  bray            : { n:'Bray', lat:53.201, lng:-6.111 },
  cabinteely      : { n:'Cabinteely', lat:53.268, lng:-6.173 },
  castleknock     : { n:'Castleknock', lat:53.382, lng:-6.360 },
  cherrywood      : { n:'Cherrywood', lat:53.257, lng:-6.160 },
  churchtown      : { n:'Churchtown', lat:53.298, lng:-6.253 },
  city            : { n:'City zone (Pearse St)', lat:53.3416, lng:-6.2398 },
  clondalkin      : { n:'Clondalkin', lat:53.323, lng:-6.395 },
  clonee          : { n:'Clonee', lat:53.422, lng:-6.436 },
  clongriffin     : { n:'Clongriffin', lat:53.415, lng:-6.168 },
  clonskeagh      : { n:'Clonskeagh', lat:53.308, lng:-6.223 },
  clontarf        : { n:'Clontarf', lat:53.364, lng:-6.207 },
  coolock         : { n:'Coolock', lat:53.392, lng:-6.209 },
  corduff         : { n:'Corduff', lat:53.396, lng:-6.355 },
  crumlin         : { n:'Crumlin', lat:53.327, lng:-6.299 },
  dalkey          : { n:'Dalkey', lat:53.276, lng:-6.102 },
  deansgrange     : { n:'Deansgrange', lat:53.283, lng:-6.170 },
  donaghmede      : { n:'Donaghmede', lat:53.398, lng:-6.185 },
  donnybrook      : { n:'Donnybrook', lat:53.318, lng:-6.233 },
  donnycarney     : { n:'Donnycarney', lat:53.375, lng:-6.221 },
  drimnagh        : { n:'Drimnagh', lat:53.328, lng:-6.318 },
  drumcondra      : { n:'Drumcondra', lat:53.365, lng:-6.254 },
  dundrum         : { n:'Dundrum', lat:53.291, lng:-6.245 },
  dunlaoghaire    : { n:'Dún Laoghaire', lat:53.294, lng:-6.135 },
  fairview        : { n:'Fairview', lat:53.364, lng:-6.233 },
  finglas         : { n:'Finglas', lat:53.391, lng:-6.296 },
  fitzwilliam     : { n:'Fitzwilliam Sq', lat:53.337, lng:-6.253 },
  foxrock         : { n:'Foxrock', lat:53.271, lng:-6.200 },
  glasnevin       : { n:'Glasnevin', lat:53.376, lng:-6.268 },
  goatstown       : { n:'Goatstown', lat:53.295, lng:-6.238 },
  greenhills      : { n:'Greenhills', lat:53.307, lng:-6.326 },
  haroldscross    : { n:"Harold's Cross", lat:53.325, lng:-6.272 },
  howth           : { n:'Howth', lat:53.390, lng:-6.065 },
  inchicore       : { n:'Inchicore', lat:53.336, lng:-6.319 },
  kilbarrack      : { n:'Kilbarrack', lat:53.391, lng:-6.174 },
  killester       : { n:'Killester', lat:53.372, lng:-6.208 },
  killiney        : { n:'Killiney', lat:53.258, lng:-6.115 },
  kilmainham      : { n:'Kilmainham', lat:53.342, lng:-6.307 },
  kimmage         : { n:'Kimmage', lat:53.310, lng:-6.281 },
  kinsealy        : { n:'Kinsealy', lat:53.430, lng:-6.202 },
  leopardstown    : { n:'Leopardstown', lat:53.276, lng:-6.211 },
  lucan           : { n:'Lucan', lat:53.358, lng:-6.451 },
  malahide        : { n:'Malahide', lat:53.451, lng:-6.154 },
  marino          : { n:'Marino', lat:53.368, lng:-6.227 },
  milltown        : { n:'Milltown', lat:53.305, lng:-6.253 },
  monkstown       : { n:'Monkstown', lat:53.293, lng:-6.155 },
  mountmerrion    : { n:'Mount Merrion', lat:53.301, lng:-6.221 },
  mulhuddart      : { n:'Mulhuddart', lat:53.405, lng:-6.387 },
  naas            : { n:'Naas', lat:53.215, lng:-6.660 },
  newcastle       : { n:'Newcastle', lat:53.303, lng:-6.518 },
  ongar           : { n:'Ongar', lat:53.400, lng:-6.410 },
  palmerstown     : { n:'Palmerstown', lat:53.349, lng:-6.387 },
  parnell         : { n:'Parnell Square', lat:53.353, lng:-6.264 },
  phibsborough    : { n:'Phibsborough', lat:53.363, lng:-6.271 },
  portmarnock     : { n:'Portmarnock', lat:53.422, lng:-6.147 },
  portobello      : { n:'Portobello', lat:53.328, lng:-6.285 },
  raheny          : { n:'Raheny', lat:53.381, lng:-6.194 },
  ranelagh        : { n:'Ranelagh', lat:53.321, lng:-6.254 },
  rathcoole       : { n:'Rathcoole', lat:53.285, lng:-6.475 },
  rathfarnham     : { n:'Rathfarnham', lat:53.299, lng:-6.273 },
  rathgar         : { n:'Rathgar', lat:53.315, lng:-6.268 },
  rathmines       : { n:'Rathmines', lat:53.326, lng:-6.263 },
  ringsend        : { n:'Ringsend', lat:53.340, lng:-6.231 },
  saggart         : { n:'Saggart', lat:53.278, lng:-6.442 },
  sallynoggin     : { n:'Sallynoggin', lat:53.279, lng:-6.143 },
  sandyford       : { n:'Sandyford', lat:53.275, lng:-6.210 },
  sandymount      : { n:'Sandymount', lat:53.327, lng:-6.206 },
  santry          : { n:'Santry', lat:53.392, lng:-6.255 },
  shankill        : { n:'Shankill', lat:53.238, lng:-6.123 },
  smithfield      : { n:'Smithfield', lat:53.349, lng:-6.270 },
  stillorgan      : { n:'Stillorgan', lat:53.291, lng:-6.201 },
  stoneybatter    : { n:'Stoneybatter', lat:53.353, lng:-6.280 },
  sutton          : { n:'Sutton', lat:53.395, lng:-6.110 },
  swords          : { n:'Swords', lat:53.460, lng:-6.218 },
  tallaght        : { n:'Tallaght', lat:53.287, lng:-6.375 },
  templeogue      : { n:'Templeogue', lat:53.303, lng:-6.311 },
  terenure        : { n:'Terenure', lat:53.312, lng:-6.279 },
  tyrellstown     : { n:'Tyrellstown', lat:53.410, lng:-6.398 },
  walkinstown     : { n:'Walkinstown', lat:53.322, lng:-6.320 },
};

// ── Vehicle capability matrix ─────────────────────────────────────────────────
var CAN_TAKE = {
  topbox:    ['pushbike','motorbike','topbox'],
  cargomax:  ['pushbike','motorbike','topbox','cargobike','cargomax'],
  cargobike: ['pushbike','motorbike','topbox','cargobike']
};
var ZONE_RESTRICTED = ['cargobike','cargomax'];
var VEH_LABELS = { topbox:'Top box', cargomax:'Cargo max', cargobike:'Cargo bike' };

// ── Fleet: 18 topbox, 8 cargomax, 4 cargobike ────────────────────────────────
var INIT_DRIVERS = [
  { id:0,  name:'Ciarán',    init:'CN', veh:'topbox',    colour:'#5B9DFF', lat:53.3489, lng:-6.2430, pos:'Custom House'  },
  { id:1,  name:'Sinéad',    init:'SN', veh:'topbox',    colour:'#5B9DFF', lat:53.3260, lng:-6.2631, pos:'Rathmines',     returnBy:90 },
  { id:2,  name:'Declan',    init:'DM', veh:'topbox',    colour:'#5B9DFF', lat:53.3416, lng:-6.2398, pos:'Pearse St'     },
  { id:3,  name:'Aoife',     init:'AF', veh:'topbox',    colour:'#5B9DFF', lat:53.3530, lng:-6.2637, pos:'Parnell Sq'    },
  { id:4,  name:'Seán',      init:'SE', veh:'topbox',    colour:'#5B9DFF', lat:53.3373, lng:-6.2528, pos:'Fitzwilliam'   },
  { id:5,  name:'Niamh',     init:'NM', veh:'topbox',    colour:'#5B9DFF', lat:53.3489, lng:-6.2600, pos:"O'Connell St"  },
  { id:6,  name:'Pádraig',   init:'PD', veh:'topbox',    colour:'#5B9DFF', lat:53.3016, lng:-6.1783, pos:'Blackrock',     returnBy:90 },
  { id:7,  name:'Bríd',      init:'BR', veh:'topbox',    colour:'#5B9DFF', lat:53.2914, lng:-6.2453, pos:'Dundrum'       },
  { id:8,  name:'Tomás',     init:'TM', veh:'topbox',    colour:'#5B9DFF', lat:53.2750, lng:-6.2100, pos:'Sandyford'     },
  { id:9,  name:'Fionnuala', init:'FO', veh:'topbox',    colour:'#5B9DFF', lat:53.4596, lng:-6.2180, pos:'Swords'        },
  { id:10, name:'Niall',     init:'NL', veh:'topbox',    colour:'#5B9DFF', lat:53.3820, lng:-6.4200, pos:'Castleknock'   },
  { id:11, name:'Eimear',    init:'EM', veh:'topbox',    colour:'#5B9DFF', lat:53.3850, lng:-6.3500, pos:'Blanchardstown'},
  { id:12, name:'Ruairí',    init:'RR', veh:'topbox',    colour:'#5B9DFF', lat:53.3578, lng:-6.4514, pos:'Lucan'         },
  { id:13, name:'Caoimhe',   init:'CM', veh:'topbox',    colour:'#5B9DFF', lat:53.2870, lng:-6.3750, pos:'Tallaght'      },
  { id:14, name:'Dáithí',    init:'DA', veh:'topbox',    colour:'#5B9DFF', lat:53.3230, lng:-6.3950, pos:'Clondalkin'    },
  { id:15, name:'Sorcha',    init:'SO', veh:'topbox',    colour:'#5B9DFF', lat:53.3280, lng:-6.2850, pos:'Portobello'    },
  { id:16, name:'Fergal',    init:'FG', veh:'topbox',    colour:'#5B9DFF', lat:53.2010, lng:-6.1110, pos:'Bray'          },
  { id:17, name:'Aoibhinn',  init:'AO', veh:'topbox',    colour:'#5B9DFF', lat:53.3180, lng:-6.2280, pos:'Ballsbridge'   },
  { id:18, name:'Mairéad',   init:'MF', veh:'cargomax',  colour:'#2DD4BF', lat:53.3416, lng:-6.2398, pos:'Pearse St'     },
  { id:19, name:'Cathal',    init:'CT', veh:'cargomax',  colour:'#2DD4BF', lat:53.3489, lng:-6.2500, pos:"O'Connell St"  },
  { id:20, name:'Orla',      init:'OR', veh:'cargomax',  colour:'#2DD4BF', lat:53.3373, lng:-6.2650, pos:'Harcourt St'   },
  { id:21, name:'Cormac',    init:'CO', veh:'cargomax',  colour:'#2DD4BF', lat:53.3450, lng:-6.2700, pos:'Christchurch'  },
  { id:22, name:'Áine',      init:'AI', veh:'cargomax',  colour:'#2DD4BF', lat:53.3530, lng:-6.2500, pos:'Dorset St'     },
  { id:23, name:'Seamus',    init:'SM', veh:'cargomax',  colour:'#2DD4BF', lat:53.3280, lng:-6.2350, pos:'Grand Canal'   },
  { id:24, name:'Clíodhna',  init:'CL', veh:'cargomax',  colour:'#2DD4BF', lat:53.3380, lng:-6.2800, pos:'Portobello'    },
  { id:25, name:'Pádraigín', init:'PI', veh:'cargomax',  colour:'#2DD4BF', lat:53.3460, lng:-6.2300, pos:'IFSC'          },
  { id:26, name:'Eoin',      init:'EO', veh:'cargobike', colour:'#FFB020', lat:53.3416, lng:-6.2550, pos:'Dame St'       },
  { id:27, name:'Siobhán',   init:'SB', veh:'cargobike', colour:'#FFB020', lat:53.3489, lng:-6.2700, pos:'Smithfield'    },
  { id:28, name:'Diarmuid',  init:'DI', veh:'cargobike', colour:'#FFB020', lat:53.3350, lng:-6.2450, pos:'Baggot St'     },
  { id:29, name:'Róisín',    init:'RO', veh:'cargobike', colour:'#FFB020', lat:53.3530, lng:-6.2800, pos:'Stoneybatter'  }
];

// ── Weighted batch options ────────────────────────────────────────────────────
var PU_W = [
  {k:'city',w:30},{k:'rathmines',w:8},{k:'portobello',w:7},{k:'parnell',w:8},
  {k:'ranelagh',w:6},{k:'donnybrook',w:6},{k:'clontarf',w:6},{k:'drumcondra',w:6},
  {k:'sandymount',w:5},{k:'glasnevin',w:5},{k:'blackrock',w:4},{k:'dundrum',w:4},
  {k:'swords',w:3},{k:'blanchardstown',w:3},{k:'lucan',w:2},{k:'bray',w:2},
  {k:'tallaght',w:2},{k:'rathfarnham',w:2},{k:'malahide',w:2},{k:'clondalkin',w:2}
];
var DE_W = [
  {k:'fitzwilliam',w:20},{k:'city',w:15},{k:'rathmines',w:7},{k:'portobello',w:6},
  {k:'parnell',w:6},{k:'ranelagh',w:6},{k:'donnybrook',w:5},{k:'clontarf',w:5},
  {k:'drumcondra',w:5},{k:'sandymount',w:5},{k:'blackrock',w:4},{k:'dundrum',w:4},
  {k:'sandyford',w:3},{k:'swords',w:3},{k:'blanchardstown',w:3},{k:'bray',w:2},
  {k:'naas',w:1},{k:'tallaght',w:2},{k:'malahide',w:2},{k:'lucan',w:2}
];
var JOB_W = [{v:'motorbike',w:50},{v:'pushbike',w:15},{v:'topbox',w:25},{v:'cargobike',w:7},{v:'cargomax',w:3}];
var SVC_W = [{v:'standard',w:80},{v:'priority',w:20}];

// ── State ─────────────────────────────────────────────────────────────────────
var drivers, map, jobCount = 0, batchRunning = false;
var sessionStats = {total:0,green:0,amber:0,red:0,block:0,override:0,match:0,conflict:0};
var recentAssignments = [];
var queueItems = [];
var currentView = 'map';

function setView(v){
  currentView = v;
  var mapEl = document.getElementById('main');
  var dashEl = document.getElementById('dashboard');
  var btnMap = document.getElementById('btn-map-view');
  var btnDash = document.getElementById('btn-dash-view');
  if(v==='map'){
    mapEl.style.display='flex';
    dashEl.style.display='none';
    btnMap.classList.add('active');
    btnDash.classList.remove('active');
    if(map) setTimeout(function(){map.invalidateSize();},100);
  } else {
    mapEl.style.display='none';
    dashEl.style.display='grid';
    btnMap.classList.remove('active');
    btnDash.classList.add('active');
    renderDashboard();
  }
}

function renderDashboard(){
  renderFleetGrid();
  renderRecentList();
  renderStats();
}

function renderFleetGrid(){
  var el=document.getElementById('fleet-body');
  if(!el) return;
  var html='';
  drivers.forEach(function(d){
    var jobs=d.jobs||[];
    var stopWarn=d.committed>=STOP_WARN_RED?'fs-red':d.committed>=STOP_WARN_AMBER?'fs-amber':'';
    var statusCls=d.locked?'fs-locked':stopWarn||( d.committed?'fs-busy':'fs-free');
    var statusTxt=d.locked?'Locked':d.committed?'On run \u00b7 '+d.committed:'Free';
    html+='<div class="fleet-row'+(d.locked?' locked':'')+'" onclick="showDriverDetail('+d.id+')" title="'+VEH_LABELS[d.veh]+'">'
      +'<div class="fleet-init" style="background:'+d.colour+'">'+d.init+'</div>'
      +'<div class="fleet-name">'+d.name+'</div>'
      +'<span class="fleet-status '+statusCls+'">'+statusTxt+'</span>'
      +'<div class="fleet-lock" onclick="event.stopPropagation();toggleLock('+d.id+')" title="Click to '+(d.locked?'unlock':'lock out')+'">'
      +(d.locked?'&#128275;':'&#128274;')+'</div>'
      +'</div>';
  });
  el.innerHTML=html;
}

function showDriverDetail(id){
  var d=drivers.find(function(x){return x.id===id;});
  if(!d) return;
  var jobs=d.jobs||[];
  var statusTxt=d.locked?'Locked':d.committed?'On run \u00b7 '+d.committed+' stop'+(d.committed>1?'s':''):'Free';
  var av=document.getElementById('dm-avatar');
  av.style.background=d.colour; av.textContent=d.init;
  document.getElementById('dm-name').textContent=d.name;
  document.getElementById('dm-sub').textContent=VEH_LABELS[d.veh]+' \u00b7 '+statusTxt;
  var body=document.getElementById('dm-body');
  if(!jobs.length){
    body.innerHTML='<div class="job-empty">No jobs assigned yet.</div>';
  } else {
    body.innerHTML=jobs.map(function(j){
      return '<div class="job-row">'
        +'<div class="job-sig sig-'+j.sig+'"></div>'
        +'<div class="job-detail">'
        +'<div class="job-id">'+j.jid+'</div>'
        +'<div class="job-route">'+j.pu+' &rarr; '+j.de+'</div>'
        +'<div class="job-meta">'+j.jobType+' &middot; '+(j.svc==='priority'?'PRIORITY':'standard')+' &middot; ETA '+j.eta+'min &middot; '+j.margin+'min margin</div>'
        +'</div></div>';
    }).join('');
  }
  document.getElementById('driver-modal').classList.add('open');
}

function closeDriverModal(){
  var m=document.getElementById('driver-modal');
  if(m) m.classList.remove('open');
}

function renderRecentList(){
  var el=document.getElementById('recent-body');
  if(!el) return;
  if(!recentAssignments.length){el.innerHTML='<div class="dash-empty">No assignments yet</div>';return;}
  var html='';
  var show=recentAssignments.slice(-15).reverse();
  show.forEach(function(a){
    var sigCol={green:(window.HAL_ACCENT||'#9CFF2E'),amber:'#FFB020',red:'#FF5C5C',block:'#E5484D'}[a.sig]||'#888';
    html+='<div class="recent-item">'
      +'<div class="recent-sig" style="background:'+sigCol+'"></div>'
      +'<div class="recent-info">'
      +'<div class="recent-job">'+a.jid+': '+a.pu+' → '+a.de+'</div>'
      +'<div class="recent-detail">'+a.driver+' · '+a.jobType+' · '+a.margin+'min margin</div>'
      +'</div></div>';
  });
  el.innerHTML=html;
}

function renderStats(){
  var ids=['total','green','amber','red','block','override','match','conflict'];
  ids.forEach(function(k){
    var el=document.getElementById('stat-'+k);
    if(el) el.textContent=sessionStats[k]||0;
  });
}

function addToQueue(cls, title, detail, actions){
  var qb=document.getElementById('queue-body');
  if(!qb) return;
  var id='q-'+Date.now();
  var actHtml='';
  if(actions){
    actHtml='<div class="q-item-actions">';
    actions.forEach(function(a){
      actHtml+='<button class="q-btn" onclick="event.stopPropagation();'+a.fn+';document.getElementById(\''+id+'\').remove();updateQueueCount()">'+a.label+'</button>';
    });
    actHtml+='</div>';
  }
  var empty=qb.querySelector('.dash-empty');
  if(empty) empty.remove();
  var item=document.createElement('div');
  item.id=id; item.className='q-item '+cls;
  // Detail is hidden by default, click title to expand
  item.innerHTML=
    '<div class="q-item-title" onclick="toggleQueueDetail(\''+id+'\')">'+
      '<span>'+title+'</span>'+
      '<span class="q-expand-icon" id="qi-'+id+'">&#9660;</span>'+
    '</div>'+
    '<div class="q-item-detail" id="qd-'+id+'" style="display:none">'+detail.replace(/\n/g,'<br>')+'</div>'+
    actHtml;
  qb.insertBefore(item,qb.firstChild);
  updateQueueCount();
}

function toggleQueueDetail(id){
  var detail=document.getElementById('qd-'+id);
  var icon=document.getElementById('qi-'+id);
  if(!detail) return;
  var open=detail.style.display!=='none';
  detail.style.display=open?'none':'block';
  if(icon) icon.innerHTML=open?'&#9660;':'&#9650;';
}

function updateQueueCount(){
  var qb=document.getElementById('queue-body');
  var qc=document.getElementById('queue-count');
  if(!qb||!qc) return;
  var count=qb.querySelectorAll('.q-item').length;
  qc.textContent=count;
  if(count===0) qb.innerHTML='<div class="dash-empty">No items requiring attention</div>';
}

// ── Maths ─────────────────────────────────────────────────────────────────────
function hav(a,b,c,d){
  var R=6371,dlat=(c-a)*Math.PI/180,dlng=(d-b)*Math.PI/180;
  var x=Math.sin(dlat/2)*Math.sin(dlat/2)+Math.cos(a*Math.PI/180)*Math.cos(c*Math.PI/180)*Math.sin(dlng/2)*Math.sin(dlng/2);
  return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}
function inZone(lat,lng){ return hav(Z9_LAT,Z9_LNG,lat,lng)<=Z9_KM; }

function bearing(lat1,lng1,lat2,lng2){
  var dLng=(lng2-lng1)*Math.PI/180;
  var lat1r=lat1*Math.PI/180, lat2r=lat2*Math.PI/180;
  var y=Math.sin(dLng)*Math.cos(lat2r);
  var x=Math.cos(lat1r)*Math.sin(lat2r)-Math.sin(lat1r)*Math.cos(lat2r)*Math.cos(dLng);
  return (Math.atan2(y,x)*180/Math.PI+360)%360;
}

function angleDiff(a,b){
  var d=Math.abs(a-b)%360;
  return d>180?360-d:d;
}

function compassDir(b){
  var dirs=['north','north-east','east','south-east','south','south-west','west','north-west'];
  return dirs[Math.round((((b%360)+360)%360)/45)%8];
}

function eta(d,lat,lng){
  var dist=hav(d.lastLat,d.lastLng,lat,lng);
  var spd=dist<8?SPD_CITY:SPD_OUT;
  return (d.busyUntil||0)+dist/spd*60;
}

// Day-type congestion factor: busier days stretch the promised SLA windows
// (slower roads → longer promises). 1.0 = Normal. Set by updateDayType().
function dayFactor(){ return window.HAL_DAY_FACTOR || 1; }

function colSLAbase(lat,lng,svc){
  var d=hav(Z9_LAT,Z9_LNG,lat,lng),out=Math.max(0,d-Z9_KM);
  return svc==='priority'?(inZone(lat,lng)?30:45+Math.round(out*2)):(60+Math.round(out*2));
}
function colSLA(lat,lng,svc){
  return Math.round(colSLAbase(lat,lng,svc)*dayFactor());
}

function delSLA(puLat,puLng,deLat,deLng,svc){
  var col=colSLAbase(puLat,puLng,svc);
  var dist=hav(puLat,puLng,deLat,deLng);
  var drive=dist/(dist<8?SPD_CITY:SPD_OUT)*60;
  return Math.round((col+drive+(svc==='priority'?10:15))*dayFactor());
}

// ── Exclusion pass ────────────────────────────────────────────────────────────
function exclude(d,puLat,puLng,deLat,deLng,jobType,svc){
  if(d.locked) return 'locked';
  if(ZONE_RESTRICTED.indexOf(d.veh)>=0&&(!inZone(puLat,puLng)||!inZone(deLat,deLng)))
    return 'zone';
  if(!CAN_TAKE[d.veh]||CAN_TAKE[d.veh].indexOf(jobType)<0)
    return 'vehicle';
  var e=eta(d,puLat,puLng);
  if(e>colSLA(puLat,puLng,svc)) return 'sla';
  // Return leg check — if driver has a committed return, would adding this job breach it?
  if(d.returnBy){
    var distToPu=hav(d.lastLat,d.lastLng,puLat,puLng);
    var timeToPu=(d.busyUntil||0)+distToPu/(distToPu<8?SPD_CITY:SPD_OUT)*60;
    var distPuDe=hav(puLat,puLng,deLat,deLng);
    var timeAtDe=timeToPu+5+distPuDe/(distPuDe<8?SPD_CITY:SPD_OUT)*60;
    var distDeHome=hav(deLat,deLng,Z9_LAT,Z9_LNG);
    var timeReturn=timeAtDe+distDeHome/(distDeHome<8?SPD_CITY:SPD_OUT)*60;
    if(timeReturn>d.returnBy) return 'return';
  }
  return null;
}

// ── Score ─────────────────────────────────────────────────────────────────────
function score(d,puLat,puLng,deLat,deLng,svc,mode){
  var e=eta(d,puLat,puLng), sla=colSLA(puLat,puLng,svc);
  var slaScore=((sla-e)/sla);
  var deadScore=Math.max(0,1-e/(sla*0.5));

  if(mode==='scheduled'){
    // Corridor logic dominates — how well does the driver's current heading match this job?
    var jobBearing=bearing(puLat,puLng,deLat,deLng);
    var drvBearing=bearing(d.lastLat,d.lastLng,puLat,puLng);
    var corridorMatch=1-(angleDiff(jobBearing,drvBearing)/180);
    return corridorMatch*60 + deadScore*30 + slaScore*10;
  }
  // On demand: SLA urgency 60%, dead mileage 20%, route fit 20%
  return slaScore*60 + deadScore*20;
}

function signal(margin){
  if(margin>=15) return 'green';
  if(margin>=5)  return 'amber';
  if(margin>=0)  return 'red';
  return 'block';
}

// ── Map ───────────────────────────────────────────────────────────────────────
function buildMap(){
  map=L.map('map',{preferCanvas:true}).setView([53.345,-6.26],12);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{attribution:'&copy; OpenStreetMap &copy; CARTO',subdomains:'abcd',maxZoom:20}).addTo(map);
  map.invalidateSize();
  L.circle([Z9_LAT,Z9_LNG],{radius:Z9_KM*1000,color:(window.HAL_ACCENT||'#9CFF2E'),weight:1.5,dashArray:'6 4',fillOpacity:0.05,fillColor:(window.HAL_ACCENT||'#9CFF2E')}).addTo(map);
}
// Leaflet sometimes captures unstable geometry when the map is created inside the
// scaled/embedded preview, leaving the vector renderer permanently broken. Probe it
// with a throwaway polyline and rebuild the map once the layout has settled if so.
function vectorOk(){
  try { var t=L.polyline([[Z9_LAT,Z9_LNG],[Z9_LAT+0.01,Z9_LNG+0.01]]).addTo(map); map.removeLayer(t); return true; }
  catch(e){ return false; }
}
function rebuildMap(){
  try{ map.remove(); }catch(e){}
  var el=document.getElementById('map'); if(el) el.innerHTML='';
  drivers.forEach(function(d){ d._marker=null; });
  buildMap();
  drawDrivers();
}
function healMap(){
  if(vectorOk()) return;
  rebuildMap();
  setTimeout(function(){ if(!vectorOk()) rebuildMap(); }, 450);
}
function initMap(){
  buildMap();
  setTimeout(healMap, 350);
}

function driverIcon(d){
  return L.divIcon({className:'',html:'<div class="drv-marker" style="background:'+d.colour+(d.locked?';opacity:0.4':'')+'">'+d.init+'</div>',iconSize:[28,28],iconAnchor:[14,14]});
}

function drawDrivers(){
  drivers.forEach(function(d){
    if(d._marker) map.removeLayer(d._marker);
    d._marker=L.marker([d.lastLat||d.lat,d.lastLng||d.lng],{icon:driverIcon(d)}).addTo(map);
    d._marker.bindTooltip(d.name+' · '+VEH_LABELS[d.veh]+(d.locked?' · LOCKED':''),{direction:'top',offset:[0,-14]});
  });
  renderDriverList();
}

function renderDriverList(){
  var el=document.getElementById('drv-list-inner');
  el.innerHTML='';
  drivers.forEach(function(d){
    var cls=d.locked?'db-locked':d.committed?'db-busy':'db-free';
    var badge=d.locked?'Locked':d.committed?'On run':'Free';
    var extra=d.committed&&!d.locked?' · '+d.committed+' stops · ~'+d.busyUntil+'min':''; if(d.returnBy) extra+=' · return '+d.returnBy+'min';
    el.innerHTML+='<div class="drv-item'+(d.locked?' locked':'')+'" onclick="showJobPopup('+d.id+')" title="Click to see jobs">'
      +'<div class="drv-dot" style="background:'+d.colour+'">'+d.init+'</div>'
      +'<div class="drv-info"><div class="drv-name">'+d.name+'</div>'
      +'<div class="drv-veh">'+VEH_LABELS[d.veh]+extra+'</div></div>'
      +'<span class="drv-badge '+cls+'">'+badge+'</span>'      +'<span style="font-size:11px;cursor:pointer;padding:0 4px;opacity:0.6" onclick="event.stopPropagation();toggleLock('+d.id+')" title="Click to '+(d.locked?'unlock':'lock out')+'">'+(d.locked?'&#128275;':'&#128274;')+'</span></div>';
  });
}

// ── Add job ───────────────────────────────────────────────────────────────────
function addJob(){
  var puKey=document.getElementById('sel-pu').value;
  var deKey=document.getElementById('sel-de').value;
  var jobType=document.getElementById('sel-type').value;
  var svc=document.getElementById('sel-svc').value;
  var pu=LOCS[puKey], de=LOCS[deKey];
  if(!pu||!de||puKey===deKey){log('log-gray','Invalid','Pickup and delivery must be different locations.');return;}
  jobCount++;
  var jid='J'+String(jobCount).padStart(2,'0');
  var puM=L.circleMarker([pu.lat,pu.lng],{radius:7,fillColor:'#FFB020',color:'#0a0a0a',weight:2,fillOpacity:1}).addTo(map).bindTooltip(jid+': '+pu.n,{direction:'top'});
  var deM=L.circleMarker([de.lat,de.lng],{radius:7,fillColor:'#cfcfcf',color:'#0a0a0a',weight:2,fillOpacity:1}).addTo(map).bindTooltip(jid+' → '+de.n,{direction:'top'});
  var lineM=L.polyline([[pu.lat,pu.lng],[de.lat,de.lng]],{color:'rgba(255,255,255,0.18)',weight:1.5,dashArray:'4 4',opacity:0.7}).addTo(map);
  runHAL(jid,pu,de,jobType,svc,puM,deM,lineM);
}

// ── HAL ───────────────────────────────────────────────────────────────────────
function runHAL(jid,pu,de,jobType,svc,puM,deM,lineM,skipMatch){
  var colSla=colSLA(pu.lat,pu.lng,svc);
  var delSla=delSLA(pu.lat,pu.lng,de.lat,de.lng,svc);

  var candidates=[], excl={zone:[],vehicle:[],sla:[],locked:[],return:[]};
  drivers.forEach(function(d){
    var r=exclude(d,pu.lat,pu.lng,de.lat,de.lng,jobType,svc);
    if(r) excl[r]=(excl[r]||[]).concat(d.name);
    else candidates.push(d);
  });

  // ── Route match check ─────────────────────────────────────────────────────
  // Match if: pickup within 2km AND (delivery within 2km OR heading within 30°)
  var ROUTE_MATCH_PU_KM = 2.0;
  var ROUTE_MATCH_DE_KM = 2.0;
  var ROUTE_MATCH_BEARING = 30; // degrees
  var routeMatches = [];
  drivers.forEach(function(d){
    if(!d.jobs || !d.jobs.length || d.locked) return;
    // Hard physical limits: a zone-restricted vehicle (cargo bike / cargo max) can't
    // serve an out-of-zone job, and the vehicle must be able to carry this parcel.
    if(ZONE_RESTRICTED.indexOf(d.veh)>=0 && (!inZone(pu.lat,pu.lng)||!inZone(de.lat,de.lng))) return;
    if(!CAN_TAKE[d.veh]||CAN_TAKE[d.veh].indexOf(jobType)<0) return;
    d.jobs.forEach(function(j){
      var jPuLoc = null, jDeLoc = null;
      Object.keys(LOCS).forEach(function(k){
        if(LOCS[k].n === j.pu) jPuLoc = LOCS[k];
        if(LOCS[k].n === j.de) jDeLoc = LOCS[k];
      });
      if(!jPuLoc || !jDeLoc) return;
      var puDist = hav(pu.lat, pu.lng, jPuLoc.lat, jPuLoc.lng);
      if(puDist > ROUTE_MATCH_PU_KM) return; // pickups must be close
      var deDist = hav(de.lat, de.lng, jDeLoc.lat, jDeLoc.lng);
      var deClose = deDist <= ROUTE_MATCH_DE_KM;
      // Also check if deliveries are heading in the same direction from pickup
      var existingBear = bearing(jPuLoc.lat, jPuLoc.lng, jDeLoc.lat, jDeLoc.lng);
      var newBear = bearing(pu.lat, pu.lng, de.lat, de.lng);
      var bearingMatch = angleDiff(existingBear, newBear) <= ROUTE_MATCH_BEARING;
      if(deClose || bearingMatch){
        var matchType = deClose ? 'same route' : 'same direction ('+Math.round(angleDiff(existingBear,newBear))+'°)';
        routeMatches.push({driver:d, job:j, puDist:puDist, deDist:deDist, matchType:matchType});
      }
    });
  });

  if(!candidates.length){
    var reasons=[];
    if(excl.locked.length)  reasons.push(excl.locked.join(', ')+' (locked)');
    if(excl.zone.length)    reasons.push(excl.zone.join(', ')+' (zone)');
    if(excl.vehicle.length) reasons.push(excl.vehicle.join(', ')+' (vehicle)');
    if(excl.sla.length)     reasons.push(excl.sla.join(', ')+' (SLA)');
    if(excl.return.length)  reasons.push(excl['return'].join(', ')+' (return leg)');
    sessionStats.total++; sessionStats.block=(sessionStats.block||0)+1;
    var bestAnyway=null,bestAnywayEta=Infinity;
    drivers.forEach(function(d){
      if(d.locked) return;
      if(ZONE_RESTRICTED.indexOf(d.veh)>=0&&(!inZone(pu.lat,pu.lng)||!inZone(de.lat,de.lng))) return;
      if(!CAN_TAKE[d.veh]||CAN_TAKE[d.veh].indexOf(jobType)<0) return;
      var e=eta(d,pu.lat,pu.lng);
      if(e<bestAnywayEta){bestAnywayEta=e;bestAnyway=d;}
    });
    var bestStr, headline, blockLabel='BLOCK';
    if(bestAnyway){
      var reason=exclude(bestAnyway,pu.lat,pu.lng,de.lat,de.lng,jobType,svc);
      var diff=Math.round(bestAnywayEta-colSla);
      bestStr='\nBest available: '+bestAnyway.name+' ('+VEH_LABELS[bestAnyway.veh]+')'
        +' \u00b7 ETA '+Math.round(bestAnywayEta)+'min';
      if(bestAnywayEta<=colSla){
        // Collection IS reachable in time — the block is a return-leg / availability issue,
        // not an SLA miss.
        bestStr+=' ('+Math.abs(diff)+'min inside collection SLA)';
        if(reason==='return'){
          headline='Collection SLA: '+colSla+'min \u00b7 reachable, but every free driver would break a committed return run.';
        } else {
          headline='Collection SLA: '+colSla+'min \u00b7 reachable, but no driver is free to take it.';
        }
      } else {
        bestStr+=' \u00b7 '+diff+'min over collection SLA';
        headline='Collection SLA: '+colSla+'min \u00b7 no driver can collect in time.';
      }
    } else {
      bestStr='\nNo driver has the right vehicle type for this job.';
      headline='Collection SLA: '+colSla+'min \u00b7 no driver can make it.';
    }
    var blockDetail=jid+': '+pu.n+' \u2192 '+de.n+' \u00b7 '+jobType+' \u00b7 '+(svc==='priority'?'PRIORITY':'standard')
      +'\n'+headline
      +bestStr+'\nCustomer call required.';
    var blockActions=bestAnyway?[{label:'Send '+bestAnyway.name+' anyway',fn:'runHALForce(\''+jid+'\','+bestAnyway.id+')'}]:null;
    addToQueue('q-block','BLOCK \u2014 '+jid,blockDetail,blockActions);
    log('log-block','BLOCK \u2014 '+jid,blockDetail);
    if(puM) puM.setStyle({fillColor:'#E5484D'});
    return;
  }

  // ── Direction conflict check ─────────────────────────────────────────────
  // If new job delivery is > 120° different from a committed driver's delivery direction,
  // and the pickups are close (within 3km), flag it - two drivers needed
  var DIR_CONFLICT_DEG = 120;
  var DIR_PICKUP_KM = 3.0;
  var FAR_COLLECTION_KM = 12; // collections beyond this from the core consolidate onto one driver
  var dirConflicts = [];
  drivers.forEach(function(d){
    if(!d.jobs || !d.jobs.length || d.locked) return;
    // Same hard limits as route-matching — never offer to batch onto a driver that
    // physically can't take the job (zone-restricted vehicle out of zone, or wrong vehicle).
    if(ZONE_RESTRICTED.indexOf(d.veh)>=0 && (!inZone(pu.lat,pu.lng)||!inZone(de.lat,de.lng))) return;
    if(!CAN_TAKE[d.veh]||CAN_TAKE[d.veh].indexOf(jobType)<0) return;
    d.jobs.forEach(function(j){
      var jPuLoc=null, jDeLoc=null;
      Object.keys(LOCS).forEach(function(k){
        if(LOCS[k].n===j.pu) jPuLoc=LOCS[k];
        if(LOCS[k].n===j.de) jDeLoc=LOCS[k];
      });
      if(!jPuLoc||!jDeLoc) return;
      var puDist=hav(pu.lat,pu.lng,jPuLoc.lat,jPuLoc.lng);
      if(puDist>DIR_PICKUP_KM) return; // pickups not close enough
      var existingBearing=bearing(jPuLoc.lat,jPuLoc.lng,jDeLoc.lat,jDeLoc.lng);
      var newBearing=bearing(pu.lat,pu.lng,de.lat,de.lng);
      var angle=angleDiff(existingBearing,newBearing);
      if(angle>=DIR_CONFLICT_DEG){
        // In the dense Z9 core there are always plenty of drivers, so two opposite-
        // direction jobs just go to two drivers \u2014 never a conflict worth surfacing.
        // A conflict only matters when the COLLECTION sits OUTSIDE the core, where
        // driver availability is thin and the backtrack / second-driver call is real.
        if(inZone(pu.lat,pu.lng)) return; // collection in Z9 \u2014 not a conflict
        // The further out the collection, the more we consolidate onto ONE driver:
        // we'd never send two vehicles all the way out (e.g. Balbriggan).
        var collFromCore = hav(Z9_LAT,Z9_LNG,pu.lat,pu.lng);
        dirConflicts.push({driver:d,job:j,angle:Math.round(angle),puDist:puDist,farOut:collFromCore>FAR_COLLECTION_KM,collKm:Math.round(collFromCore),existingBearing:existingBearing,newBearing:newBearing});
      }
    });
  });

  if(dirConflicts.length && !routeMatches.length && !skipMatch){
    var dc=dirConflicts[0];
    sessionStats.conflict=(sessionStats.conflict||0)+1;
    var existDir=compassDir(dc.existingBearing), newDir=compassDir(dc.newBearing);
    var pickupPhrase = dc.puDist < 0.25
      ? 'collects at the same pickup ('+pu.n+')'
      : 'collects at '+pu.n+' (on the way)';
    var recLine = dc.farOut
      ? 'Collection ~'+dc.collKm+'km out \u2014 too far to split, one driver recommended.'
      : 'One driver would have to double back. Two drivers recommended.';
    var conflictDetail='<span style="color:#fff;font-weight:700">'+dc.driver.name+' is running '+dc.job.jid+' '+existDir+' ('+dc.job.pu+' &rarr; '+dc.job.de+')</span>'
      +'\n<span style="color:#E15CFF;font-weight:700">New '+jid+' '+pickupPhrase+' but delivers '+newDir+' to '+de.n+'</span>'
      +'\nDelivery heads the opposite way \u2014 '+dc.angle+'\u00b0 off the current route.'
      +'\n'+recLine;
    addToQueue('q-conflict','DIRECTION CONFLICT \u2014 '+jid, conflictDetail,[
      {label:'Batch onto '+dc.driver.name+(dc.farOut?' (recommended)':''), fn:'assignJob(\''+jid+'\','+dc.driver.id+')'},
      {label:'Assign separately', fn:'assignJobBest(\''+jid+'\')'}
    ]);
    log('log-amber','DIRECTION CONFLICT \u2014 '+jid+' (waiting for dispatcher)', conflictDetail);
    if(puM) puM.setStyle({fillColor:'#E15CFF'});
    pendingJobs[jid]={pu:pu,de:de,jobType:jobType,svc:svc,puM:puM,deM:deM};
    if(currentView==='dash') renderDashboard();
    return;
  }

  // ── Surface route match prompt ────────────────────────────────────────────
  if(routeMatches.length && !skipMatch){
    var m=routeMatches[0];
    var puDistStr=m.puDist<0.1?'same location':Math.round(m.puDist*1000)+'m away';
    sessionStats.match=(sessionStats.match||0)+1;
    var matchDetail='<span style="color:#fff;font-weight:700">'+m.driver.name+' &mdash; current '+m.job.jid+': '+m.job.pu+' &rarr; '+m.job.de+'</span>'
      +'\n<span style="color:var(--accent);font-weight:700">New '+jid+': '+pu.n+' &rarr; '+de.n+' · '+jobType+' · '+(svc==='priority'?'PRIORITY':'standard')+'</span>'
      +'\nPickup '+puDistStr+' · '+m.matchType
      +'\nBatch with '+m.driver.name+' or assign to a separate driver?';
    addToQueue('q-amber','ROUTE MATCH — '+jid, matchDetail,[
      {label:'Batch with '+m.driver.name, fn:'assignJob(\''+jid+'\','+m.driver.id+')'},
      {label:'Assign separately', fn:'assignJobBest(\''+jid+'\')'}
    ]);
    log('log-amber','ROUTE MATCH — '+jid+' (waiting for dispatcher)', matchDetail);
    if(puM) puM.setStyle({fillColor:'#FFB020'});
    pendingJobs[jid]={pu:pu,de:de,jobType:jobType,svc:svc,puM:puM,deM:deM};
    if(currentView==='dash') renderDashboard();
    return;
  }

  var mode=document.getElementById('sel-mode')?document.getElementById('sel-mode').value:'ondemand';
  candidates.sort(function(a,b){return score(b,pu.lat,pu.lng,de.lat,de.lng,svc,mode)-score(a,pu.lat,pu.lng,de.lat,de.lng,svc,mode);});
  var best=candidates[0];
  var e=eta(best,pu.lat,pu.lng);
  var margin=colSla-e;
  var sig=signal(margin);
  var col={green:(window.HAL_ACCENT||'#9CFF2E'),amber:'#FFB020',red:'#FF5C5C',block:'#E5484D'}[sig];

  // Update driver committed state
  best.committed=(best.committed||0)+1;
  var fromLat=best.lastLat, fromLng=best.lastLng; // driver's projected position before this job
  var distToPu=hav(best.lastLat,best.lastLng,pu.lat,pu.lng);
  var timeToPu=(best.busyUntil||0)+distToPu/(distToPu<8?SPD_CITY:SPD_OUT)*60;
  var distPuDe=hav(pu.lat,pu.lng,de.lat,de.lng);
  best.busyUntil=Math.round(timeToPu+5+distPuDe/(distPuDe<8?SPD_CITY:SPD_OUT)*60);
  best.lastLat=de.lat; best.lastLng=de.lng;
  if(!best.jobs) best.jobs=[];
  best.jobs.push({jid:jid,pu:pu.n,de:de.n,jobType:jobType,svc:svc,eta:Math.round(e),margin:Math.round(margin),sig:sig});

  // Redraw route from the driver's projected position → pickup → delivery,
  // then advance the driver's dot to this delivery (their new projected position).
  if(lineM) map.removeLayer(lineM);
  L.polyline([[fromLat,fromLng],[pu.lat,pu.lng],[de.lat,de.lng]],{color:col,weight:2.5,opacity:0.8}).addTo(map);
  if(best._marker) best._marker.setLatLng([best.lastLat,best.lastLng]);
  if(puM) puM.setStyle({fillColor:col});

  // Exclusion summary
  var exclParts=[];
  if(excl.locked.length)  exclParts.push(excl.locked.join(', ')+' (locked)');
  if(excl.zone.length)    exclParts.push(excl.zone.join(', ')+' (zone)');
  if(excl.vehicle.length) exclParts.push(excl.vehicle.join(', ')+' (vehicle)');
  if(excl.sla.length)     exclParts.push(excl.sla.join(', ')+' (SLA)');
  if(excl['return']&&excl['return'].length) exclParts.push(excl['return'].join(', ')+' (return leg)');

  // Alternatives
  var alts=candidates.slice(1,3).map(function(d){
    var de2=Math.round(eta(d,pu.lat,pu.lng));
    return d.name+' (ETA '+de2+'min, '+Math.round(colSla-de2)+'min margin)';
  }).join('; ');

  var sigLabel={green:'ASSIGN',amber:'FLAG',red:'ASSIGN NOW',block:'BLOCK'}[sig];
  var sigClass={green:'log-green',amber:'log-amber',red:'log-red',block:'log-block'}[sig];

  log(sigClass, sigLabel+' — '+best.name,
    jid+': '+pu.n+' \u2192 '+de.n+' \u00b7 '+jobType+' \u00b7 '+(svc==='priority'?'PRIORITY':'standard')+(mode==='scheduled'?' \u00b7 SCHEDULED':'')+
    '\nAssigned to '+best.name+' ('+VEH_LABELS[best.veh]+') \u00b7 ETA '+Math.round(e)+'min \u00b7 '+Math.round(margin)+'min margin'+
    '\nCollection SLA: '+colSla+'min \u00b7 Delivery SLA: '+delSla+'min'+
    (exclParts.length?'\nExcluded: '+exclParts.join('; '):'')+ 
    (alts?'\nAlternatives: '+alts:''), jid, best.name);
  // Track stats and recent
  sessionStats.total++;
  sessionStats[sig]=(sessionStats[sig]||0)+1;
  recentAssignments.push({jid:jid,pu:pu.n,de:de.n,driver:best.name,jobType:jobType,sig:sig,margin:Math.round(margin)});
  if(currentView==='dash') renderDashboard();
  else renderDriverList();

  renderDriverList();
}

// ── Batch ─────────────────────────────────────────────────────────────────────
// ── Healthwave multi-stop dispatch ───────────────────────────────────────────
var HW_RUNS = [
  { name:'South', colour:'#FF5C5C', stops:[
    {pu:'Argus House', de:'Ballsbridge', loc:{lat:53.318,lng:-6.228}},
    {pu:'Argus House', de:'Dundrum',     loc:{lat:53.291,lng:-6.245}},
    {pu:'Argus House', de:'Dundrum',     loc:{lat:53.291,lng:-6.245}},
    {pu:'Argus House', de:'Sandyford',   loc:{lat:53.275,lng:-6.210}},
    {pu:'Argus House', de:'Sandyford',   loc:{lat:53.275,lng:-6.210}},
    {pu:'Argus House', de:'Sandyford',   loc:{lat:53.275,lng:-6.210}},
    {pu:'Argus House', de:'Bray',        loc:{lat:53.201,lng:-6.111}}
  ]},
  { name:'City / SW', colour:'#5B9DFF', stops:[
    {pu:'Argus House', de:'City zone',       loc:{lat:53.342,lng:-6.253}},
    {pu:'Argus House', de:'Portobello',      loc:{lat:53.328,lng:-6.285}},
    {pu:'Argus House', de:'Portobello',      loc:{lat:53.328,lng:-6.285}},
    {pu:'Argus House', de:'Portobello',      loc:{lat:53.328,lng:-6.285}},
    {pu:'Argus House', de:'Portobello',      loc:{lat:53.328,lng:-6.285}},
    {pu:'Argus House', de:'Portobello',      loc:{lat:53.328,lng:-6.285}},
    {pu:'Argus House', de:'Clondalkin',      loc:{lat:53.323,lng:-6.395}},
    {pu:'Argus House', de:'Tallaght',        loc:{lat:53.287,lng:-6.375}},
    {pu:'Argus House', de:'Naas',            loc:{lat:53.215,lng:-6.660}}
  ]},
  { name:'West', colour:'#C77DFF', stops:[
    {pu:'Argus House', de:'Blanchardstown', loc:{lat:53.389,lng:-6.378}},
    {pu:'Argus House', de:'Blanchardstown', loc:{lat:53.389,lng:-6.378}},
    {pu:'Argus House', de:'Blanchardstown', loc:{lat:53.389,lng:-6.378}},
    {pu:'Argus House', de:'Lucan',          loc:{lat:53.358,lng:-6.451}}
  ]}
];

var ARGUS = {lat:53.335, lng:-6.255, n:'Argus House'};
var HW_DEADLINE = 19*60; // 7pm in minutes from midnight
var HW_DISPATCH = 13*60; // 1pm dispatch

function runHealthwave(){
  var SPD = 22; // average
  // Score each run against available drivers using scheduled mode (corridor fit)
  var prompt_lines = ['\nThree Healthwave runs ready for dispatch:\n'];
  var usedDrivers = [];

  HW_RUNS.forEach(function(run){
    // Find best driver for this corridor using corridor scoring
    var runEndLoc = run.stops[run.stops.length-1].loc;
    var best = null, bestScore = -Infinity;
    drivers.forEach(function(d){
      if(d.locked || usedDrivers.indexOf(d.id)>=0) return;
      // Zone check - all Healthwave stops - only topbox can do Naas/Bray
      var hasOutside = run.stops.some(function(s){ return !inZone(s.loc.lat,s.loc.lng); });
      if(hasOutside && d.veh!=='topbox') return;
      // Corridor score - how well does driver match run direction
      var runBear = bearing(ARGUS.lat,ARGUS.lng,runEndLoc.lat,runEndLoc.lng);
      var drvBear = bearing(d.lastLat,d.lastLng,ARGUS.lat,ARGUS.lng);
      var corridorMatch = 1-(angleDiff(runBear,drvBear)/180);
      // Estimate run time
      var pos = {lat:ARGUS.lat,lng:ARGUS.lng};
      var runTime = 0;
      run.stops.forEach(function(s){
        var dist=hav(pos.lat,pos.lng,s.loc.lat,s.loc.lng);
        runTime += dist/SPD*60 + 5;
        pos = s.loc;
      });
      var finishTime = HW_DISPATCH + runTime;
      var margin = HW_DEADLINE - finishTime;
      if(margin < 0) return; // can't make deadline
      var sc = corridorMatch*60 + (margin/HW_DEADLINE)*20;
      if(sc > bestScore){ bestScore=sc; best=d; best._hwRunTime=runTime; best._hwMargin=margin; }
    });

    if(best){
      usedDrivers.push(best.id);
      var finHr = Math.floor((HW_DISPATCH+best._hwRunTime)/60);
      var finMin = Math.round((HW_DISPATCH+best._hwRunTime)%60);
      var marginMins = Math.round(best._hwMargin);
      prompt_lines.push(run.name+' run ('+run.stops.length+' stops) → '+best.name+' ('+VEH_LABELS[best.veh]+')');
      prompt_lines.push('  Done by '+finHr+':'+String(finMin).padStart(2,'0')+' · '+marginMins+' min margin to 7pm deadline');
      // Draw markers
      run.stops.forEach(function(s){
        L.circleMarker([s.loc.lat,s.loc.lng],{radius:6,fillColor:run.colour,color:'#fff',weight:2,fillOpacity:0.9})
          .addTo(map).bindTooltip('HW: '+s.de,{direction:'top'});
      });
      // Draw route line from best driver → Argus → stops
      var pts = [[best.lat,best.lng],[ARGUS.lat,ARGUS.lng]];
      run.stops.forEach(function(s){ pts.push([s.loc.lat,s.loc.lng]); });
      L.polyline(pts,{color:run.colour,weight:2,opacity:0.7,dashArray:'6 3'}).addTo(map);
    } else {
      prompt_lines.push(run.name+' run — no suitable driver available');
    }
    prompt_lines.push('');
  });

  log('log-amber','HEALTHWAVE — confirm or adjust?', prompt_lines.join('\n'));
}

function weightedPick(arr){
  var total=arr.reduce(function(s,x){return s+x.w;},0),r=Math.random()*total;
  for(var i=0;i<arr.length;i++){r-=arr[i].w;if(r<=0)return arr[i];}
  return arr[arr.length-1];
}

function runBatch(){
  if(batchRunning) return;
  var n=parseInt(document.getElementById('batch-size').value);
  var delay=parseInt(document.getElementById('batch-speed').value)*1000;
  var btn=document.getElementById('btn-batch');
  var prog=document.getElementById('batch-progress');
  btn.disabled=true; document.getElementById('btn-add-job').disabled=true; batchRunning=true;
  try {
  var ZONE_LOC_W = PU_W.filter(function(l){
    var loc=LOCS[l.k]; if(!loc) return false;
    return hav(Z9_LAT,Z9_LNG,loc.lat,loc.lng)<=Z9_KM;
  });
  var jobs=[];
  for(var i=0;i<n;i++){
    var pu,de,jtype,att=0;
    do{
      jtype=weightedPick(JOB_W).v;
      var zoneOnly=(jtype==='cargobike'||jtype==='cargomax');
      var puPool=zoneOnly?ZONE_LOC_W:PU_W;
      pu=weightedPick(puPool);
      var dePool=zoneOnly?ZONE_LOC_W.filter(function(l){return l.k!==pu.k;}):DE_W;
      de=weightedPick(dePool.length?dePool:ZONE_LOC_W);
      att++;
    } while(pu.k===de.k&&att<30);
    jobs.push({pu:pu.k,de:de.k,jtype:jtype,svc:weightedPick(SVC_W).v});
  }
  } catch(err){
    console.error('batch setup failed', err);
    btn.disabled=false; document.getElementById('btn-add-job').disabled=false;
    batchRunning=false; prog.textContent='Batch could not start \u2014 try again';
    return;
  }
  function runNext(idx){
    if(idx>=jobs.length){
      btn.disabled=false; document.getElementById('btn-add-job').disabled=false;
      batchRunning=false; prog.textContent='Batch complete \u2014 '+n+' jobs assigned'; return;
    }
    var j=jobs[idx];
    prog.textContent='Job '+(idx+1)+' of '+n+' \u00b7 '+j.jtype+' \u00b7 '+(j.svc==='priority'?'PRIORITY':'standard');
    document.getElementById('sel-pu').value=j.pu;
    document.getElementById('sel-de').value=j.de;
    document.getElementById('sel-type').value=j.jtype;
    document.getElementById('sel-svc').value=j.svc;
    try { addJob(); } catch(e){ console.error('batch job failed', e); }
    setTimeout(function(){runNext(idx+1);},delay);
  }
  runNext(0);
}

// ── Lock/Unlock ───────────────────────────────────────────────────────────────
var overrideLog = [];

function overrideJob(entryId, jid, assigned){
  var reason = prompt('Override reason for '+jid+' (assigned to '+assigned+'):');
  if(!reason) return;
  var entry = document.getElementById(entryId);
  if(!entry) return;
  // Mark entry as overridden
  entry.style.opacity='0.5';
  entry.style.textDecoration='line-through';
  // Add override note
  var note = document.createElement('div');
  note.className='override-note';
  note.style.textDecoration='none';
  note.style.opacity='1';
  note.innerHTML='<b>Override:</b> '+reason;
  entry.appendChild(note);
  entry.style.textDecoration='none';
  entry.style.opacity='1';
  // Hide override button
  var btn = entry.querySelector('.btn-override');
  if(btn) btn.style.display='none';
  // Log
  overrideLog.push({jid:jid,assigned:assigned,reason:reason,time:new Date().toLocaleTimeString()});
  sessionStats.override=(sessionStats.override||0)+1;
  // Add to log
  logOverride(jid, assigned, reason);
}

function logOverride(jid, assigned, reason){
  var el=document.getElementById('log');
  var now=new Date();
  var t=now.getHours()+':'+String(now.getMinutes()).padStart(2,'0')+':'+String(now.getSeconds()).padStart(2,'0');
  var entry=document.createElement('div');
  entry.className='log-entry log-gray';
  entry.innerHTML='<div class="log-time">'+t+'</div>'
    +'<div class="log-title">OVERRIDE — '+jid+'</div>'
    +'<div class="log-detail">'+assigned+' reassigned · Reason: '+reason+'</div>';
  el.insertBefore(entry,el.firstChild);
}

var pendingJobs = {};
var STOP_WARN_AMBER = 5;  // warn at this many committed stops
var STOP_WARN_RED   = 8;  // queue alert at this many committed stops

var DAY_LABELS = ['Normal','Busy','Flat out','Overload'];

var DAY_FACTORS = [1.0, 1.20, 1.40, 1.65];
var DAY_COLORS  = ['#9CFF2E', '#FFB020', '#FF8C3C', '#FF5C5C'];

function updateDayType(val){
  var v = parseInt(val);
  window.HAL_DAY_FACTOR = DAY_FACTORS[v-1];
  var btns = document.querySelectorAll('#day-btns .day-btn');
  btns.forEach(function(b){
    var bv = parseInt(b.getAttribute('data-day'));
    if(bv===v){ b.classList.add('active'); } else { b.classList.remove('active'); }
  });
  var diff = Math.round((DAY_FACTORS[v-1]-1)*100);
  var note = document.getElementById('day-note');
  if(note){ note.textContent = diff===0 ? 'SLA windows at baseline' : 'Roads slower \u00b7 SLA windows +'+diff+'%'; }
  // Set batch size suggestion based on day type
  var sizes = [12, 20, 30, 40];
  var batchEl = document.getElementById('batch-size');
  var batchVal = document.getElementById('batch-size-val');
  if(batchEl){ batchEl.value = sizes[v-1]; batchVal.textContent = sizes[v-1]; }
}

function runHALForce(jid, driverId){
  // Dispatcher override on a blocked job - send specific driver anyway
  var p=pendingJobs[jid];
  var pu,de,jobType,svc,puM,deM;
  if(p){ pu=p.pu; de=p.de; jobType=p.jobType; svc=p.svc; puM=p.puM; deM=p.deM; delete pendingJobs[jid]; }
  var d=drivers.find(function(x){return x.id===driverId;});
  if(!d) return;
  // Run a direct assign
  jobCount++;
  var jidNew=jid; // keep same jid
  d.committed=(d.committed||0)+1;
  if(!d.jobs) d.jobs=[];
  var e=eta(d,pu.lat,pu.lng);
  var colSla=colSLA(pu.lat,pu.lng,svc);
  var margin=colSla-e;
  d.jobs.push({jid:jidNew,pu:pu.n,de:de.n,jobType:jobType,svc:svc,eta:Math.round(e),margin:Math.round(margin),sig:'red'});
  var fromLat=d.lastLat, fromLng=d.lastLng;
  var distToPu=hav(d.lastLat,d.lastLng,pu.lat,pu.lng);
  var timeToPu=(d.busyUntil||0)+distToPu/(distToPu<8?SPD_CITY:SPD_OUT)*60;
  var distPuDe=hav(pu.lat,pu.lng,de.lat,de.lng);
  d.busyUntil=Math.round(timeToPu+5+distPuDe/(distPuDe<8?SPD_CITY:SPD_OUT)*60);
  d.lastLat=de.lat; d.lastLng=de.lng;
  L.polyline([[fromLat,fromLng],[pu.lat,pu.lng],[de.lat,de.lng]],{color:'#FF5C5C',weight:2.5,opacity:0.8}).addTo(map);
  if(d._marker) d._marker.setLatLng([d.lastLat,d.lastLng]);
  if(puM) puM.setStyle({fillColor:'#FF5C5C'});
  recentAssignments.push({jid:jidNew,pu:pu.n,de:de.n,driver:d.name,jobType:jobType,sig:'red',margin:Math.round(margin)});
  sessionStats.red=(sessionStats.red||0)+1;
  log('log-red','DISPATCHER OVERRIDE — '+d.name,
    jidNew+': '+pu.n+' \u2192 '+de.n+' \u00b7 Sent despite SLA breach \u00b7 ETA '+Math.round(e)+'min \u00b7 '+Math.round(margin)+'min margin');
  if(d.committed>=STOP_WARN_RED){
    addToQueue('q-amber','HIGH LOAD \u2014 '+d.name,
      d.name+' now has '+d.committed+' committed stops.'
      +'\nConsider redistributing if new jobs arrive for this corridor.');
  }
  if(currentView==='dash') renderDashboard();
  else renderDriverList();
}

function assignJob(jid, driverId){
  var p=pendingJobs[jid]; if(!p) return;
  var d=drivers.find(function(x){return x.id===driverId;});
  if(!d){assignJobBest(jid);return;}
  delete pendingJobs[jid];
  runHALAssign(jid,p.pu,p.de,p.jobType,p.svc,p.puM,p.deM,d);
}

function assignJobBest(jid){
  var p=pendingJobs[jid]; if(!p) return;
  delete pendingJobs[jid];
  runHAL(jid,p.pu,p.de,p.jobType,p.svc,p.puM,p.deM,null,true);
}

// Batch the pending job onto a specific driver (the "Batch with …" action).
function runHALAssign(jid,pu,de,jobType,svc,puM,deM,d){
  // Backstop: never batch a job onto a vehicle that physically can't take it.
  if(ZONE_RESTRICTED.indexOf(d.veh)>=0 && (!inZone(pu.lat,pu.lng)||!inZone(de.lat,de.lng))){
    log('log-gray','Re-routed \u2014 '+jid, VEH_LABELS[d.veh]+'s stay inside Z9 \u2014 assigning to the best available driver instead.');
    runHAL(jid,pu,de,jobType,svc,puM,deM,null,true);
    return;
  }
  jobCount++;
  var colSla=colSLA(pu.lat,pu.lng,svc);
  var e=eta(d,pu.lat,pu.lng);
  var margin=colSla-e;
  var sig=signal(margin);
  var col={green:(window.HAL_ACCENT||'#9CFF2E'),amber:'#FFB020',red:'#FF5C5C',block:'#E5484D'}[sig];
  d.committed=(d.committed||0)+1;
  if(!d.jobs) d.jobs=[];
  d.jobs.push({jid:jid,pu:pu.n,de:de.n,jobType:jobType,svc:svc,eta:Math.round(e),margin:Math.round(margin),sig:sig});
  var fromLat=d.lastLat, fromLng=d.lastLng; // projected position before this job
  var distToPu=hav(d.lastLat,d.lastLng,pu.lat,pu.lng);
  var timeToPu=(d.busyUntil||0)+distToPu/(distToPu<8?SPD_CITY:SPD_OUT)*60;
  var distPuDe=hav(pu.lat,pu.lng,de.lat,de.lng);
  d.busyUntil=Math.round(timeToPu+5+distPuDe/(distPuDe<8?SPD_CITY:SPD_OUT)*60);
  d.lastLat=de.lat; d.lastLng=de.lng;
  L.polyline([[fromLat,fromLng],[pu.lat,pu.lng],[de.lat,de.lng]],{color:col,weight:2.5,opacity:0.8}).addTo(map);
  if(d._marker) d._marker.setLatLng([d.lastLat,d.lastLng]);
  if(puM) puM.setStyle({fillColor:col});
  recentAssignments.push({jid:jid,pu:pu.n,de:de.n,driver:d.name,jobType:jobType,sig:sig,margin:Math.round(margin)});
  sessionStats.total++; sessionStats[sig]=(sessionStats[sig]||0)+1;
  log({green:'log-green',amber:'log-amber',red:'log-red',block:'log-block'}[sig],'BATCHED \u2014 '+d.name,
    jid+': '+pu.n+' \u2192 '+de.n+' \u00b7 '+jobType+' \u00b7 '+(svc==='priority'?'PRIORITY':'standard')
    +'\nBatched onto '+d.name+' ('+VEH_LABELS[d.veh]+') \u00b7 now '+d.committed+' stops \u00b7 ETA '+Math.round(e)+'min \u00b7 '+Math.round(margin)+'min margin', jid, d.name);
  if(d.committed>=STOP_WARN_RED){
    addToQueue('q-amber','HIGH LOAD \u2014 '+d.name,
      d.name+' now has '+d.committed+' committed stops.'
      +'\nConsider redistributing if new jobs arrive for this corridor.');
  }
  if(currentView==='dash') renderDashboard(); else renderDriverList();
}

var activePopupId = null;

function showJobPopup(id){
  var d=drivers.find(function(x){return x.id===id;});
  if(!d) return;
  // If same driver clicked again, close
  if(activePopupId===id){closeJobPopup();return;}
  activePopupId=id;
  var popup=document.getElementById('job-popup');
  var title=document.getElementById('job-popup-title');
  var body=document.getElementById('job-popup-body');
  title.innerHTML='<span style="display:inline-flex;align-items:center;gap:7px">'
    +'<span style="width:20px;height:20px;border-radius:50%;background:'+d.colour+';display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff">'+d.init+'</span>'
    +d.name+' &mdash; '+VEH_LABELS[d.veh]+'</span>';
  var jobs=d.jobs||[];
  if(!jobs.length){
    body.innerHTML='<div class="job-empty">No jobs assigned yet.</div>';
  } else {
    body.innerHTML=jobs.map(function(j){
      return '<div class="job-row">'
        +'<div class="job-sig sig-'+j.sig+'"></div>'
        +'<div class="job-detail">'
        +'<div class="job-id">'+j.jid+'</div>'
        +'<div class="job-route">'+j.pu+' &rarr; '+j.de+'</div>'
        +'<div class="job-meta">'+j.jobType+' &middot; '+(j.svc==='priority'?'PRIORITY':'standard')+' &middot; ETA '+j.eta+'min &middot; '+j.margin+'min margin</div>'
        +'</div></div>';
    }).join('');
  }
  popup.classList.add('open');
}

function closeJobPopup(){
  document.getElementById('job-popup').classList.remove('open');
  activePopupId=null;
}

function toggleLock(id){
  var d=drivers.find(function(x){return x.id===id;});
  if(!d) return;
  d.locked=!d.locked;
  if(d._marker){map.removeLayer(d._marker);d._marker=L.marker([d.lastLat||d.lat,d.lastLng||d.lng],{icon:driverIcon(d)}).addTo(map);}
  if(currentView==='dash') renderDashboard(); else renderDriverList();
  log(d.locked?'log-gray':'log-green',d.name+(d.locked?' locked out':' unlocked'),
    d.locked?d.name+' excluded from all assignments until manually unlocked.':d.name+' returned to the available pool.');
}

// ── Reset ─────────────────────────────────────────────────────────────────────
function resetAll(){
  jobCount=0;
  batchRunning=false;
  var bb=document.getElementById('btn-batch'); if(bb) bb.disabled=false;
  var ba=document.getElementById('btn-add-job'); if(ba) ba.disabled=false;
  drivers=INIT_DRIVERS.map(function(d){return Object.assign({},d,{committed:0,locked:false,busyUntil:0,lastLat:d.lat,lastLng:d.lng,_marker:null,jobs:[],returnBy:d.returnBy||null});});
  map.eachLayer(function(layer){if(!(layer instanceof L.TileLayer))map.removeLayer(layer);});
  L.circle([Z9_LAT,Z9_LNG],{radius:Z9_KM*1000,color:(window.HAL_ACCENT||'#9CFF2E'),weight:1.5,dashArray:'6 4',fillOpacity:0.05,fillColor:(window.HAL_ACCENT||'#9CFF2E')}).addTo(map);
  drawDrivers();
  document.getElementById('log').innerHTML='';
  document.getElementById('batch-progress').textContent='';
  closeJobPopup();
  sessionStats={total:0,green:0,amber:0,red:0,block:0,override:0,match:0,conflict:0};
  recentAssignments=[]; queueItems=[]; pendingJobs={};
  var qb=document.getElementById('queue-body');
  if(qb) qb.innerHTML='<div class="dash-empty">No items requiring attention</div>';
  updateQueueCount();
  if(currentView==='dash') renderDashboard();
}

// ── Log ───────────────────────────────────────────────────────────────────────
function log(cls,title,detail,jid,assigned){
  var el=document.getElementById('log');
  var now=new Date();
  var t=now.getHours()+':'+String(now.getMinutes()).padStart(2,'0')+':'+String(now.getSeconds()).padStart(2,'0');
  var entry=document.createElement('div');
  var entryId='log-'+Date.now()+'-'+Math.random().toString(36).slice(2,6);
  entry.id=entryId;
  entry.className='log-entry '+cls;
  var overrideBtn='';
  if(jid&&assigned&&(cls==='log-green'||cls==='log-amber'||cls==='log-red')){
    overrideBtn='<div class="log-actions"><button class="btn-override" onclick="overrideJob(\''+entryId+'\',\''+jid+'\',\''+assigned+'\')">Override</button></div>';
  }
  entry.innerHTML='<div class="log-time">'+t+'</div><div class="log-title">'+title+'</div><div class="log-detail">'+detail.replace(/\n/g,'<br>')+'</div>'+overrideBtn;
  el.insertBefore(entry,el.firstChild);
}

// ── Init ──────────────────────────────────────────────────────────────────────
function populateSelects(){
  var keys=Object.keys(LOCS).sort(function(a,b){return LOCS[a].n.localeCompare(LOCS[b].n);});
  var pu=document.getElementById('sel-pu'), de=document.getElementById('sel-de');
  if(pu && !pu.options.length){
    keys.forEach(function(k){
      pu.insertAdjacentHTML('beforeend','<option value="'+k+'">'+LOCS[k].n+'</option>');
      de.insertAdjacentHTML('beforeend','<option value="'+k+'">'+LOCS[k].n+'</option>');
    });
    pu.value='city'; de.value='fitzwilliam';
  }
}
function wireControls(){
  var b=function(id){return document.getElementById(id);};
  if(b('btn-map-view')) b('btn-map-view').onclick=function(){setView('map');};
  if(b('btn-dash-view')) b('btn-dash-view').onclick=function(){setView('dash');};
  if(b('btn-add-job')) b('btn-add-job').onclick=addJob;
  if(b('btn-reset')) b('btn-reset').onclick=resetAll;
  if(b('btn-batch')) b('btn-batch').onclick=runBatch;
  if(b('btn-hw')) b('btn-hw').onclick=runHealthwave;
  if(b('job-popup-close')) b('job-popup-close').onclick=closeJobPopup;
  if(b('dm-close')) b('dm-close').onclick=closeDriverModal;
  var dm=b('driver-modal'); if(dm) dm.addEventListener('click',function(e){ if(e.target===dm) closeDriverModal(); });
  if(b('day-type')) b('day-type').addEventListener('input',function(e){updateDayType(e.target.value);});
  document.querySelectorAll('#day-btns .day-btn').forEach(function(btn){ btn.onclick=function(){ updateDayType(btn.getAttribute('data-day')); }; });
  if(b('batch-size')) b('batch-size').addEventListener('input',function(e){b('batch-size-val').textContent=e.target.value;});
  if(b('batch-speed')) b('batch-speed').addEventListener('input',function(e){b('batch-speed-val').textContent=e.target.value;});
}
window.HALBoot=function(){
  if(window.__halBooted) return;
  window.__halBooted=true;
  populateSelects();
  wireControls();
  updateDayType('1');
  drivers=INIT_DRIVERS.map(function(d){return Object.assign({},d,{committed:0,locked:false,busyUntil:0,lastLat:d.lat,lastLng:d.lng,_marker:null,jobs:[],returnBy:d.returnBy||null});});
  initMap();
  drawDrivers();
  document.getElementById('hal-status').textContent='HAL ONLINE';
  document.getElementById('hal-status').classList.add('running');
};